# datalad install https://github.com/OpenNeuroDatasets/ds004869.git

library(tidyverse)
library(fs)

a <- fs::dir_info(".", recurse=TRUE)

symlinks <- a %>%
  filter(type=="symlink")

for(i in 1:nrow(symlinks)) {
  file_delete(symlinks$path[i])
  file_create(symlinks$path[i])
}
