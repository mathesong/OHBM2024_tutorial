library(stringr)
library(tidyverse)

dirs <- list.dirs(recursive = T)[-1]

for(i in 1:length(dirs)) {
  old_dirname <- dirs[i]
  new_dirname <- str_replace(old_dirname, "ses-02", "ses-blocked")
  new_dirname <- str_replace(new_dirname, "ses-01", "ses-baseline")
  file.rename(old_dirname, new_dirname)
}

files <- list.files(recursive = T)

for(i in 1:length(files)) {
  old_filename <- files[i]
  new_filename <- str_replace(old_filename, "ses-02", "ses-blocked")
  new_filename <- str_replace(new_filename, "ses-01", "ses-baseline")
  file.rename(old_filename, new_filename)
}
